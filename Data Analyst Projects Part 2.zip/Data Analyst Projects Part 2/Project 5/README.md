# (Dataset Exploration Title)
## by (your name here)


## Dataset

 The dataset I chose to work with is called Prosper Loan Data, which was provided by Udacity instructors. The format for this data was comma seperated values(csv). The original dataset contained 113,937 loans with 81 features. Some of the features or attributes are Terms, Borrower APR, Is home owners, Prosper Score, Loan Amount, Loan Status, Stated Monthly Income etc. I then did some cleaning to suit the questions I wanted to investigate. After Cleaning i was left with  84853 loans with 18 features or variables. I did some further cleaning while I was exploring the data

## Summary of Findings

In this project I was based my focus on investigating the dataset to predict Borrower APR and also to find relationships between Prosper Score, Is Homeowner, Stated Monthly Income, and other variables. I also wanted to find the attributes that are associated with Prosper Score. In order to investigate this datasets, I considered three explorations approaches, that is the univariate exploration, bivariate exploration and the last one being multivaiariate explorations.

### Univariate Exploration 
The following are my findings:

1. most of the loans taken are from employed people, followed by full-time people and the self-employed and so on to the lowest as part-time people.
2. most of the loans taken are current and loans that are past due are put in segments.
3. most common length of loans is 36 months, followed by 60 months and the 12 months
4. the rating with the highest count of borrowers is 4.0 and the rating with the lowest count of borrowers is 7.0.
5.  the distribution of Borrower APR shows 2 peaks of the data ,the first peak has a mode around 0.20 or 20% and the second peak is around 35% or 0.35.
6. The dataset had the mean Prosper score at 6.0 and has higher peaks at 4.0,6.0 and 8.0.

### Bivariate Exploration 
The following are my findings:

1.It was seen that there is a negative correlation between between Borrower APR and Loan Origional Amount. This might be the cause of high loans being given to borrowers with high risk scores.
2.It was shown that a negative correlation exist between Borrower APR and Prosper Score. It indicates that borrowers with lower prosper score pay more for the loan taken.
3.it was clearly seen that there is negative linear relationship between Borrower APR and Stated monthly income.
4.It could be seen from the heat map and scatterplot that there is a weak positive correlation between Borrower APR and Debt to income ratio
5.  the correlation between Delinquencies in Last 7 Years and Borrower APR is weakily positive correlated.
6. those who pay the most loans are those in category 0(unknown), followed by 10(cosmetic procedure) and so on.
7. it was shown that unemployed borrowers have the highest Borrower APR and this is accurate with employed with the lowest.
8. showed that people in the 36 month term had the highest Borrower APR.
9. people who were not home owners had higher borrower APR than people who had homes.
10.  showed that Prosper Score and state monthly income are weakly positive correlated.
11. showed that Prosper Score and loan original amount are weakly positive correlated.
12. showed that the mean of loan original amount increase as the term in months increases.
13.  shows a positive correlation betwen Loan Original Amount and State Monthly Income.

### Multivariate Exploration 
The following are my findings:

1.It could be seen that the borrowers with a prosper score of 7 for 12 months pay lesser than the other two ters(36 and 60 months).
2.I realized that homeowners have lower Borrower APR than non homeowners as the prosper score is above 1.
3. Home owners take larger loans as their prosper scores increases than non home owners.

## Key Insights for Presentation

For my presentattion, I looked at the insights and distribution of Borrower APR, Loan original amount, Prosper Score, Is Home owner, and Stated Monthly Income. After that I moved on to talk about the relationship between Borrower APR and Prosper Score, Borrower APR and Stated Monthly Income, Borrower APR and Debt to Income Ratio, Borrower APR and Term, Prosper score and Stated Monthly incomes,Prosper Score and Loan Original Amount, Prosper Score and Debt To Income Ratio. Lastly I investigated the interaction between Borrower APR and Prosper Score across Term, Borrower APR and Prosper Score across  IsHomeowners, Loan Amount and Prosper score across  Homeownership.